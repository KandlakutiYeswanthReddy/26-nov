import { Component, OnInit } from '@angular/core';
import { Router, Event, NavigationEnd } from '@angular/router';
import { Cart } from './../model/Cart';
import { Order } from './../model/Order';
import { Status } from './../model/Status';
import { AuthenticateService } from '../authenticate.service';
import { CartService } from './../cart.service';
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cart: Cart

  order: Order
  no: number
  successFlag: boolean
  progressFlag: boolean

  constructor(public cartService: CartService, public authService: AuthenticateService, public router: Router) {
    this.order = new Order()
    this.no = 0
    this.cart = new Cart()

    this.cartService.orders = []
  }

  deleteCartItem(cartid, index) {
    this.cartService.deleteCartItem(cartid)
      .subscribe((res: Status) => {
        if (res.queryStatus)
          this.cartService.carts.splice(index, 1)
      })
  }

  ngOnInit() {
  }

  placeOrder(id) {

    for (let i = 0; i < this.cartService.carts.length; i++) {
      this.no = this.cartService.carts[i].total + this.no
      this.cartService.carts[i].status = true
    }

    this.order.ufk = this.authService.currentUser.id
    this.order.oid = 0
    this.order.total = this.no

    this.cartService.placeOrder(this.order)

    if (this.successFlag) {
      window.alert("your order placed successfully !!!")
    }

  }
}
